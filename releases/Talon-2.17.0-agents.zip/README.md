# Talon для агентских рантаймов

<img src="assets/talon.png" alt="Иконка Talon" width="96" height="96" />

Пакет добавляет разбор репозитория, реализацию фич, работу с Python, PowerShell, Linux, Windows Server, удалённым доступом и QA. Общий навык `talon` работает с инструментами выбранного рантайма и выдаёт задачи исследователю, исполнителю, QA или ревьюеру по мере необходимости. Модель, делегирование и доступ к серверу определяет конфигурация рантайма.

В обычной задаче попросите «Напиши Python-скрипт, прогони его на тестовых данных и покажи результат». Для сервера укажите доступный SSH-алиас и нужный объект, например службу или задачу. Помощник `talon/scripts/verify.py` даёт код завершения, проверку ожидаемого вывода, таймаут и сводку по свежему JUnit.

Для работы с Git локальной модели нужен рантайм с доступом к репозиторию и Git CLI. Навык использует профиль Git того пользователя ОС или контейнера, в котором выполняются команды. На другом компьютере задай свои `user.name` и привязанный к GitHub `user.email` в Git этого окружения. Адрес GitHub `noreply` также подходит. [Профиль GitHub для коммитов](https://docs.github.com/en/account-and-profile/how-tos/email-preferences/setting-your-commit-email-address)

## Подключение к проекту

1. Распакуй архив и скопируй каталоги из `skills/` в `.agents/skills/` корня проекта. Помимо основного `talon` появятся `git`, `stack`, `checks`, `directory`, `delivery` и пять навыков `harness-*`. При обновлении замени эти каталоги свежими копиями, сохранив свои изменения при необходимости.
2. Добавь подходящие правила из `PROJECT-RULES.md` в действующий файл инструкций проекта для автоматического выбора Talon. Когда Talon выбран, память включена по умолчанию. Она хранится в `.agents/talon/learned.md` или в `.talon/learned.md`, если `.agents/` защищён. Отключение можно указать правилами проекта или в задаче.
3. Открой проект в своём рантайме и начни новую сессию. Пробный запрос — «Используй навык talon. Покажи, где начинается установка в этом проекте и как проверить повторный запуск. Только разбор».

| Рантайм | Как подхватывает навык |
| --- | --- |
| Hermes Agent | Стартуй в Git-проекте и доверь ему загрузку локальных навыков через `hermes skills trust`, если проект ещё не доверен. [Навыки Hermes](https://hermes-agent.nousresearch.com/docs/user-guide/features/skills#project-local-skills) |
| OpenCode | Запусти из каталога проекта. В OpenCode 2 можно явно выбрать `@talon`. В OpenCode 1 используй `/talon`, если имя свободно. [OpenCode 2](https://opencode.ai/docs/skills/) · [OpenCode 1](https://github.com/anomalyco/opencode/blob/v1.19.6/packages/web/src/content/docs/skills.mdx) |
| OpenClaw | Помести навык в рабочую папку агента или сессии. Проверь его через `openclaw skills list` и вызови через `/skill talon`. Одноимённый навык в `skills/` имеет приоритет. [Навыки OpenClaw](https://docs.openclaw.ai/tools/skills) |
| Pi | Открой доверенный проект и вызови `/skill:talon`. Роль ревьюера можно выполнить в текущей сессии. При уже настроенном делегировании используй имеющиеся подагенты. [Навыки Pi](https://docs.pi.dev/latest/skills) |
| DeepSeek Harness | Открой проект как рабочую папку с файловыми навыками и вызови `/talon` с задачей. Одноимённый навык в `.dsh/skills/` имеет приоритет. [Файловые навыки и приоритет](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.2-rc.5/packages/skill/skill-filesystem/README.md#roots-and-priority) · [Вызов навыка](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.2.2-rc.5/packages/client/ui-skill/README.md#use-this-package) |

Распакованный пакет также содержит стандартный `plugin.json` формата Agent Plugins. Hermes Agent и OpenClaw с поддержкой этого формата могут загружать каталог как пакет навыков. Для памяти и правил конкретного проекта используй настройку выше. [Agent Plugins](https://agent-plugins.org/specification) · [Hermes Agent](https://hermes-agent.nousresearch.com/docs/developer-guide/plugins#portable-agent-plugins-v1-packages) · [OpenClaw](https://docs.openclaw.ai/plugins/bundles)

В Claude Code запустите `claude --plugin-dir /путь/к/распакованному-архиву` из каталога вашего проекта и вызовите `/talon:talon`. В списке `/plugin` проверьте загруженный Talon. Для Claude Agent SDK укажите этот же абсолютный путь в `ClaudeAgentOptions.plugins`. [Пример загрузки из каталога](https://github.com/anthropics/claude-agent-sdk-python/blob/main/examples/plugin_example.py)
